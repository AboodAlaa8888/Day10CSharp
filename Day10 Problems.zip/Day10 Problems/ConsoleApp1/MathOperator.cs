﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class MathOperator
    {
        public static int Operate(int a, int b, Func<int, int, int> operation)
        {
            return operation(a, b);
        }
    }
}
