﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class NumberFilter
    {
        public static List<int> Filter(List<int> numbers, Predicate<int> predicate)
        {
            List<int> result = new List<int>();
            foreach (var num in numbers)
            {
                if (predicate(num))
                    result.Add(num);
            }
            return result;
        }
    }
}
