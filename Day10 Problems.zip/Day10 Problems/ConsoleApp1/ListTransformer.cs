﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public delegate R Transformer<T, R>(T input);

    public class ListTransformer
    {
        public static List<R> TransformList<T, R>(List<T> inputList, Transformer<T, R> transformer)
        {
            List<R> result = new List<R>();
            foreach (var item in inputList)
            {
                result.Add(transformer(item));
            }
            return result;
        }
    }
}
