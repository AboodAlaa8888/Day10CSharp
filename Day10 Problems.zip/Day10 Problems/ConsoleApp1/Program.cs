﻿
using ConsoleApp1;
using System;

class Program
{
    static void Main()
    {
        #region Part01 Problem01
        //Employee[] employees = new Employee[]
        //{
        //    new Employee { Id = 1, Name = "Ali", Salary = 5000 },
        //    new Employee { Id = 2, Name = "Sara", Salary = 3000 },
        //    new Employee { Id = 3, Name = "Omar", Salary = 7000 },
        //};

        //SortingAlgorithm<Employee> sorter = new SortingAlgorithm<Employee>();
        //sorter.Sort(employees, (e1, e2) => e1.Salary.CompareTo(e2.Salary));

        //foreach (var emp in employees)
        //    Console.WriteLine(emp);
        #endregion

        #region Part01 Problem02
        //int[] numbers = { 5, 1, 9, 3, 7 };

        //SortingTwo<int> sorter = new SortingTwo<int>();
        //sorter.Sort(numbers, (x, y) => y.CompareTo(x));

        //Console.WriteLine("Sorted in Descending Order:");
        //foreach (var num in numbers)
        //    Console.WriteLine(num);
        #endregion

        #region Part01 Problem03
        //string[] words = { "apple", "kiwi", "banana", "pear", "strawberry" };

        //SortingTwo<string> sorter = new SortingTwo<string>();
        //sorter.Sort(words, (s1, s2) => s1.Length.CompareTo(s2.Length));

        //Console.WriteLine("Strings sorted by length (ascending):");
        //foreach (var word in words)
        //    Console.WriteLine(word);
        #endregion

        #region Part01 Problem04
        //Employee[] employees = new Employee[]
        //{
        //    new Employee { Id = 1, Name = "Ali", Salary = 4000 },
        //    new Manager  { Id = 2, Name = "Sara", Salary = 6000, TeamSize = 5 },
        //    new Employee { Id = 3, Name = "Omar", Salary = 3000 },
        //    new Manager  { Id = 4, Name = "Laila", Salary = 7000, TeamSize = 10 }
        //};

        //SortingTwo<Employee> sorter = new SortingTwo<Employee>();
        //sorter.Sort(employees, (e1, e2) => e1.Salary.CompareTo(e2.Salary));

        //Console.WriteLine("Employees and Managers sorted by Salary:");
        //foreach (var emp in employees)
        //    Console.WriteLine(emp);
        #endregion

        #region Part01 Problem05
        //Employee[] employees = new Employee[]
        //{
        //    new Employee { Id = 1, Name = "Ali", Salary = 5000 },
        //    new Employee { Id = 2, Name = "Mohammed", Salary = 7000 },
        //    new Employee { Id = 3, Name = "Sara", Salary = 4000 },
        //    new Employee { Id = 4, Name = "Omar", Salary = 6000 }
        //};

        //SortingTwo2<Employee> sorter = new SortingTwo2<Employee>();

        //// Compare based on Name length (ascending order)
        //Func<Employee, Employee, bool> compareByNameLength = (e1, e2) => e1.Name.Length > e2.Name.Length;

        //sorter.Sort(employees, compareByNameLength);

        //Console.WriteLine("Employees sorted by Name length:");
        //foreach (var emp in employees)
        //    Console.WriteLine(emp);
        #endregion

        #region Part01 Problem06
        //int[] numbers1 = { 9, 4, 7, 1, 3 };
        //int[] numbers2 = { 8, 2, 6, 5, 0 };

        //SortingTwo<int> sorter = new SortingTwo<int>();

        //sorter.Sort(numbers1, delegate (int x, int y)
        //{
        //    return x.CompareTo(y);
        //});

        //Console.WriteLine("Sorted with Anonymous Function:");
        //foreach (var num in numbers1)
        //    Console.WriteLine(num);

        //sorter.Sort(numbers2, (x, y) => x.CompareTo(y));

        //Console.WriteLine("\nSorted with Lambda Expression:");
        //foreach (var num in numbers2)
        //    Console.WriteLine(num);
        #endregion

        #region Part01 Problem07
        //int[] numbers = { 10, 20, 30, 40 };

        //Console.WriteLine("Before Swap:");
        //foreach (var n in numbers)
        //    Console.WriteLine(n);

        //SortingAlgorithm<int>.Swap(numbers, 1, 3);

        //Console.WriteLine("\nAfter Swap:");
        //foreach (var n in numbers)
        //    Console.WriteLine(n);
        #endregion

        #region Part01 Problem08
        //Employee[] employees = new Employee[]
        //{
        //    new Employee { Id = 1, Name = "Ali", Salary = 5000 },
        //    new Employee { Id = 2, Name = "Sara", Salary = 5000 },
        //    new Employee { Id = 3, Name = "Omar", Salary = 3000 },
        //    new Employee { Id = 4, Name = "Laila", Salary = 7000 },
        //    new Employee { Id = 5, Name = "Ahmed", Salary = 5000 }
        //};

        //SortingTwo<Employee> sorter = new SortingTwo<Employee>();

        //sorter.Sort(employees, (e1, e2) =>
        //{
        //    int salaryComparison = e1.Salary.CompareTo(e2.Salary);
        //    if (salaryComparison == 0)
        //        return e1.Name.CompareTo(e2.Name);
        //    return salaryComparison;
        //});

        //Console.WriteLine("Employees sorted by Salary, then by Name:");
        //foreach (var emp in employees)
        //    Console.WriteLine(emp);
        #endregion

        #region Part01 Problem09
        //int defaultInt = Utility.GetDefault<int>();
        //double defaultDouble = Utility.GetDefault<double>();
        //bool defaultBool = Utility.GetDefault<bool>();

        //string defaultString = Utility.GetDefault<string>();
        //object defaultObject = Utility.GetDefault<object>();

        //Console.WriteLine("Default values of Value Types:");
        //Console.WriteLine($"int: {defaultInt}");
        //Console.WriteLine($"double: {defaultDouble}");
        //Console.WriteLine($"bool: {defaultBool}");

        //Console.WriteLine("\nDefault values of Reference Types:");
        //Console.WriteLine($"string: {(defaultString == null ? "null" : defaultString)}");
        //Console.WriteLine($"object: {(defaultObject == null ? "null" : defaultObject)}");
        #endregion

        #region Part01 Problem10
        //Employee2[] employees = new Employee2[]
        //{
        //    new Employee2 { Id = 1, Name = "Ali", Salary = 5000 },
        //    new Employee2 { Id = 2, Name = "Sara", Salary = 3000 },
        //    new Employee2 { Id = 3, Name = "Omar", Salary = 7000 }
        //};

        //SortingAlgorithm2<Employee2> sorter = new SortingAlgorithm2<Employee2>();

        //Employee2[] clonedEmployees = sorter.CloneArray(employees);

        //sorter.Sort(clonedEmployees, (e1, e2) => e1.Salary.CompareTo(e2.Salary));

        //Console.WriteLine("Original Employees:");
        //foreach (var emp in employees)
        //    Console.WriteLine(emp);

        //Console.WriteLine("\nCloned and Sorted Employees:");
        //foreach (var emp in clonedEmployees)
        //    Console.WriteLine(emp);
        #endregion

        #region Part01 Problem11
        //List<string> words = new List<string> { "hello", "world", "csharp", "delegate" };

        //var uppercased = Transformer.ApplyTransformation(words, s => s.ToUpper());
        //var reversed = Transformer.ApplyTransformation(words, s => new string(s.Reverse().ToArray()));
        //var prefixed = Transformer.ApplyTransformation(words, s => ">> " + s);

        //Console.WriteLine("Uppercased:");
        //uppercased.ForEach(Console.WriteLine);

        //Console.WriteLine("\nReversed:");
        //reversed.ForEach(Console.WriteLine);

        //Console.WriteLine("\nPrefixed:");
        //prefixed.ForEach(Console.WriteLine);
        #endregion

        #region Part01 Problem12
        //IntOperation add = (a, b) => a + b;
        //IntOperation subtract = (a, b) => a - b;
        //IntOperation multiply = (a, b) => a * b;
        //IntOperation divide = (a, b) => b != 0 ? a / b : 0;

        //int x = 20, y = 5;

        //Console.WriteLine($"Addition: {Calculator.PerformOperation(x, y, add)}");
        //Console.WriteLine($"Subtraction: {Calculator.PerformOperation(x, y, subtract)}");
        //Console.WriteLine($"Multiplication: {Calculator.PerformOperation(x, y, multiply)}");
        //Console.WriteLine($"Division: {Calculator.PerformOperation(x, y, divide)}");
        #endregion

        #region Part01 Problem13
        //List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };
        //var stringList = ListTransformer.TransformList(numbers, n => $"Number: {n}");

        //Console.WriteLine("Integers to Strings:");
        //stringList.ForEach(Console.WriteLine);

        //List<string> words = new List<string> { "hello", "world", "delegate", "generic" };
        //var lengths = ListTransformer.TransformList(words, w => w.Length);

        //Console.WriteLine("\nStrings to Lengths:");
        //lengths.ForEach(Console.WriteLine);

        //List<double> doubles = new List<double> { 3.14, 2.71, 7.89 };
        //var rounded = ListTransformer.TransformList(doubles, d => (int)Math.Round(d));

        //Console.WriteLine("\nDoubles to Rounded Integers:");
        //rounded.ForEach(Console.WriteLine);
        #endregion

        #region Part01 Problem14
        //List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };

        //Func<int, int> square = x => x * x;

        //var squaredNumbers = ListProcessor.ApplyTransformation(numbers, square);

        //Console.WriteLine("Squared Numbers:");
        //squaredNumbers.ForEach(Console.WriteLine);
        #endregion

        #region Part01 Problem15
        //List<string> words = new List<string> { "Hello", "World", "C#", "Delegates" };

        //Action<string> print = s => Console.WriteLine(s);

        //Console.WriteLine("Printing words with Action<string>:");
        //StringProcessor.ApplyAction(words, print);
        #endregion

        #region Part01 Problem16
        //List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        //Predicate<int> isEven = n => n % 2 == 0;

        //var evenNumbers = NumberFilter.Filter(numbers, isEven);

        //Console.WriteLine("Even Numbers:");
        //evenNumbers.ForEach(Console.WriteLine);
        #endregion

        #region Part01 Problem17
        //List<string> words = new List<string> { "apple", "banana", "apricot", "cherry", "avocado" };

        //var startsWithA = StringFilter.Filter(words, delegate (string s) { return s.StartsWith("a"); });

        //var containsRR = StringFilter.Filter(words, delegate (string s) { return s.Contains("rr"); });

        //Console.WriteLine("Strings starting with 'a':");
        //startsWithA.ForEach(Console.WriteLine);

        //Console.WriteLine("\nStrings containing 'rr':");
        //containsRR.ForEach(Console.WriteLine);
        #endregion

        #region Part01 Problem18
        //int x = 10, y = 5;

        //int sum = MathOperator.Operate(x, y, delegate (int a, int b) { return a + b; });
        //int difference = MathOperator.Operate(x, y, delegate (int a, int b) { return a - b; });
        //int product = MathOperator.Operate(x, y, delegate (int a, int b) { return a * b; });

        //Console.WriteLine($"Addition: {sum}");
        //Console.WriteLine($"Subtraction: {difference}");
        //Console.WriteLine($"Multiplication: {product}");
        #endregion

        #region Part01 Problem19
        //List<string> words = new List<string> { "apple", "bat", "cherry", "dog", "elephant" };

        //var longWords = StringFilter.Filter(words, s => s.Length > 3);
        //var containsE = StringFilter.Filter(words, s => s.Contains("e"));

        //Console.WriteLine("Strings with length > 3:");
        //longWords.ForEach(Console.WriteLine);

        //Console.WriteLine("\nStrings containing 'e':");
        //containsE.ForEach(Console.WriteLine);
        #endregion

        #region Part01 Problem20
        //double x = 8, y = 2;

        //double division = MathOperator2.Operate(x, y, (a, b) => b != 0 ? a / b : double.NaN);
        //double exponent = MathOperator2.Operate(x, y, (a, b) => Math.Pow(a, b));

        //Console.WriteLine($"Division: {division}");
        //Console.WriteLine($"Exponentiation: {exponent}");
        #endregion
    }
}