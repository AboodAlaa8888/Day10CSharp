﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class StringProcessor
    {
        public static void ApplyAction(List<string> inputList, Action<string> action)
        {
            foreach (var str in inputList)
            {
                action(str);
            }
        }
    }
}
