﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class StringFilter
    {
        public static List<string> Filter(List<string> inputList, Predicate<string> condition)
        {
            List<string> result = new List<string>();
            foreach (var str in inputList)
            {
                if (condition(str))
                    result.Add(str);
            }
            return result;
        }
    }
}
