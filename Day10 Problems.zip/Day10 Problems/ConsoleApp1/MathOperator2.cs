﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class MathOperator2
    {
        public static double Operate(double a, double b, Func<double, double, double> operation)
        {
            return operation(a, b);
        }
    }
}
