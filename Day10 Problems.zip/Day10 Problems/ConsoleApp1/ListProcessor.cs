﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class ListProcessor
    {
        public static List<int> ApplyTransformation(List<int> inputList, Func<int, int> transformer)
        {
            List<int> result = new List<int>();
            foreach (var num in inputList)
            {
                result.Add(transformer(num));
            }
            return result;
        }
    }
}
