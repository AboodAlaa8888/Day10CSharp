﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public delegate int IntOperation(int a, int b);

    public class Calculator
    {
        public static int PerformOperation(int x, int y, IntOperation operation)
        {
            return operation(x, y);
        }
    }

}
